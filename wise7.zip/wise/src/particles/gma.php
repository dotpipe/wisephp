<?php

  session_start();
  setcookie("sameSite", "Lax", 0, "/", "localhost", true, true);
?>

<html>
<head>
<div id="particles-js"></div>
<script src="../switches/pipes.js"></script>
<script src="http://cdn.jsdelivr.net/particles.js/2.0.0/particles.min.js"></script>
<style>
body {
  margin: 0;
  font: normal 75% Arial, Helvetica, sans-serif;
}
canvas {
  display: block;
  vertical-align: bottom;
}
quote {
  position: absolute;
  top: 55%;
  left: 50%;
  width: 350px;
  color: rgb(233, 190, 152);
  font-size: 1.8em;
  text-align: right;
  line-height: 14px;
  padding-top: 1px;
  padding-bottom: 2px;
  font-family: Helvetica, Arial, sans-serif;
  font-weight: bold;
  z-index: 3;
}
#texthere  {
  position:absolute;
  display:block;
  width:450;
  height:25;
  top: 150%;
  left: 150;
  bottom: 35%;
  background: white;
}
#guests {
  position:absolute;
  display:block;
  overflow-x:hidden;
  overflow-y:auto;
  width:450;
  height:300;
  top: 110%;
  left: 150;
  bottom: 35%;
  background:lightgray;
} /* ---- particles.js container ---- */
#particles-js {
  position: absolute;
  width: 100%;
  height: 40%;
  top: 10%;
  background-color: #b61924;
  background-image: url("");
  background-repeat: no-repeat;
  background-size: cover;
  background-position: 50% 50%;
}
rbg {
  position: absolute;
  top: 20%;
  left: 55%;
  width: 300px;
  height: 200px;
  color: rgba(155, 5, 5, 0.45);
  font-size: 6em;
  text-align: center;
  line-height: 14px;
  padding-right: 3px;
  padding-bottom: 2px;
  text-shadow: slategrey;
  
}
rose {
  position: absolute;
  top: 20%;
  left: 150px;
  width: 450px;
  color: red;
  font-size: 0.8em;
  text-align: right;
  line-height: 14px;
  padding-top: 1px;
  padding-bottom: 2px;
  font-family: Helvetica, Arial, sans-serif;
  font-weight: bold;
  z-index: 3;
}
footer {
  vertical-align: bottom;
  background: #000022;
  position: relative;
  top: 95%;
  left: 0;
  width: 100%;
  right: 1;
  color: azure;
  font-size: 2em;
  overflow-x: hidden;
  text-align: center;
  line-height: 14px;
  padding-top: 20px;
  padding-bottom: 30px; 
  font-family: Helvetica, Arial, sans-serif;
  font-weight: bold;
  z-index: 3;
}
obit {
  position: absolute;
  top: 65%;
  left: 50%;
  width: 350px;
  color: red;
  font-size: 0.8em;
  text-align: right;
  line-height: 14px;
  padding-top: 1px;
  padding-bottom: 2px;
  font-family: Helvetica, Arial, sans-serif;
  font-weight: bold;
  z-index: 3;
}
blinkbox {
  background: #000022;
  position: absolute;
  top: 45%;
  left: 50%;
  width: 200px;
  color: red;
  font-size: 0.8em;
  text-align: right;
  line-height: 14px;
  padding-top: 1px;
  padding-right: 3px;
  padding-bottom: 2px; 
  font-family: Helvetica, Arial, sans-serif;
  font-weight: bold;
  z-index: 3;
}
</style>
<script>
particlesJS("particles-js", {
  particles: {
    number: { value: 389, density: { enable: true, value_area: 800 } },
    color: { value: "#ffffff" },
    shape: {
      type: "circle",
      stroke: { width: 0, color: "#000000" },
      polygon: { nb_sides: 5 },
      image: { src: "img/github.svg", width: 100, height: 100 }
    },
    opacity: {
      value: 0.5,
      random: false,
      anim: { enable: false, speed: 1, opacity_min: 0.1, sync: false }
    },
    size: {
      value: 3,
      random: true,
      anim: { enable: false, speed: 40, size_min: 0.1, sync: false }
    },
    line_linked: {
      enable: true,
      distance: 150,
      color: "#ffffff",
      opacity: 0.4,
      width: 1
    },
    move: {
      enable: true,
      speed: 6,
      direction: "none",
      random: false,
      straight: false,
      out_mode: "out",
      bounce: false,
      attract: { enable: false, rotateX: 600, rotateY: 1200 }
    }
  },
  interactivity: {
    detect_on: "canvas",
    events: {
      onhover: { enable: true, mode: "repulse" },
      onclick: { enable: true, mode: "push" },
      resize: true
    },
    modes: {
      grab: { distance: 400, line_linked: { opacity: 1 } },
      bubble: { distance: 400, size: 40, duration: 2, opacity: 8, speed: 3 },
      repulse: { distance: 200, duration: 0.4 },
      push: { particles_nb: 4 },
      remove: { particles_nb: 2 }
    }
  },
  retina_detect: true
});
var update;
update = function () {
  if (window.pJSDom[0].pJS.particles && window.pJSDom[0].pJS.particles.array) {
    count_particles.innerText = window.pJSDom[0].pJS.particles.array.length;
  }
  requestAnimationFrame(update);
};
requestAnimationFrame(update);

</script>
</head>
<body>
  <script src="../plugins/filler.js"></script>
  <pre>
  <div id="guests">
  </div>
    <input id="texthere" name="texthere" method="GET" insert="guests" ajax="new_name.php">
  </pre>
  <br><h1 style="text-align:center;"><i>God give us strength in these times...</i></h1>  
  <rbg><i><pre>Rosetta</pre><pre>Grinnell</pre></i></rbg>
  <div id="fb-root"></div>
  <script async defer crossorigin="anonymous" src="https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v9.0&appId=1169242246609738&autoLogAppEvents=1" nonce="A62J64bd"></script>
  <rose class="fb-post" data-href="https://www.facebook.com/photo/?fbid=105576838009678&amp;set=a.105576854676343" data-width="500" data-show-text="true"><blockquote cite="https://www.facebook.com/photo.php?fbid=105576838009678&amp;set=a.105576854676343&amp;type=3" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/rosetta.grinnell.35"><a href="https://www.facebook.com/photo.php?fbid=105576838009678&amp;set=a.105576854676343&amp;type=3"</a></blockquote></rose>
  <blinkbox style="z-index:2;">&hearts; &hearts; &hearts; &hearts; &hearts; for rosey</blinkbox>
  <quote>"Never ending life. Rhythmic, Genetic, Reciprocating, Meticulous, Sound, Balanced, and a Miracle of God."</quote>
  <obit><img src="gma.jpg"/></obit>
  <footer>In memoriam of Rosetta B Grinnell</footer>
</body>
</html>