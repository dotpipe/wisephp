# wise
PHP Library and MVC

wise is a brainchild of many languages. This includes Java, C++, C#, and others.
The MVC portion is something to be looked over and gotten into and used to. But it's not the only
way to code, so we'll fix that someday (kidding). The Containers are mostly out of
Java 8 and >= C++14 So I got that going for me. The newest addition, Ditto, is a fully
encompassed way to make templates for PHPUnit Tests. So also, that's a big what if,
if you're leaning on downloading the package.

$ php -f ditto_cli.php input_folder/ output_folder/

And it'll run through doing every class you have, leaving template file after template file
of credible templates of the PHPUnit type. Shouldn't be so disgusting to do those things,
so as it's has been the hardest part of coding, or maybe, more mundane, it is there to help
you not get burned out. Your corporate job might be quite happy you picked that up.

We also, aft download, can use CRUD which you'll find in the wise/src/oauth2 directory.
Hint hint yes it's there. (Needs some tweaking of inputs to some functions that are
setup for you to make your site personally for your needs). It all functions, to my knowledge.

PASM! OMG I almost forgot to tell you. In wise/src/pasm, you'll find a class which just goes
on forever. It is every Oracle-based Assembly function. Now, you might ask, well what's the point?
It's like being nearer to the drain in a sink. While that other code has to go around the sink
and slowly get in, PASM is constructed in the same way that Assembly is, so its driven the same.
Make sense? Good. If not, you'll be impressed if you use it.

As you noticed, I have given you several books to read in order to facilitate the use of the full
wise package. A lot of the functions in PASM were completely, or at least modestly changed for
people who didn't want to do ASM in its nativity. So this will actually lean you into the spirit
of that great language. A total course in it, in your browser. Who says good things come in small
packages?

There is also some Chat stuff that's ready to go. I'll be adding the database file soon. Thanks!