<?php
	echo '<table>
		<tr>
			<th style="background:opacity:0.0;border:0px;"></th>
		</tr>
	</table>';
?>
