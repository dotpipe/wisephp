# Wireframe MVC
MVC Stand-alone

This is also available as a separate class in swatchphp/adoms
