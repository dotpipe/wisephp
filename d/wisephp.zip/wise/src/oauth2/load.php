<?php

require_once __DIR__ . '../../../../vendor/autoload.php';
include_once('crud.php');
include_once('oauth2owner.php');
include_once('userclass.php');
