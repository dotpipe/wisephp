<html><head>
<script src="allow.js"></script>
</head>
<body>
</body>
</html>
<script>createBar();</script>