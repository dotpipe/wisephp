# Redist
Here: the beginning of the best SaaS routing and balancing/DDOS prevention system. Please, allow yourself to get comfy.

# Cloning vs Downloading
It doesn't show that anyone uses the program if they don't clone, so I suggest cloning. There are no dependencies. So don't worry about having to download a block of code you otherwise would not need. Happy days!
