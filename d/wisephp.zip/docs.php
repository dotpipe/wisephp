<?php declare (strict_types = 1);

namespace wise\src\lib;

require "vendor/autoload.php";

session_start();
file_put_contents("example.txt",":):):):)");
?>
<style>
.class-names {
    border-radius: 30; 
    padding: 5;
    background-color:lightslategray;
}
table {
    border-radius: 200;
    width:900px;
    column-count: 3;
    margin-left:auto;
    margin-right:auto;
    overflow: clip;
    overflow-x: clip;
}
#carousel {

    border-radius: 30px;
    width:900px;
    margin-left:auto;
    margin-right:auto;
    overflow: clip;
    overflow-x: clip;
}
#carousel-house
{
    border-radius: 30px;
    overflow: clip;
    overflow-x: clip;
    width:400px;
    display:table;
    z-index:5;
    max-height: 100px;
}
#carousel-button-left {
    z-index: 4;
    display:none;
    position: fixed;
    left:10px;
    top:45px;
}
#carousel-button-right {
    z-index: 4;
    display:none;
    position: fixed;
    left:770px;
    top:45px;
}
#carousel-window {
    overflow-wrap:break-word;
    overflow-x: scroll;
    display:table-row;
    height:150px;
    border-top-left-radius: 5px;
    border-top-right-radius: 5px;
    border-bottom-left-radius: 5px;
    border-bottom-right-radius: 5px;
}
::-webkit-scrollbar {
    width: 0px;  /* Remove scrollbar space */
    background: transparent;  /* Optional: just make scrollbar invisible */
}
.carousel-cell {
    border-top-left-radius: 20px;
    border-top-right-radius: 20px;
    border-bottom-left-radius: 20px;
    border-bottom-right-radius: 20px;
    overflow: hidden hidden;
    text-align:justify;
    max-height:50%;
    min-width:150px;
    max-width: 150px;
    height:140;
    z-index: 3;
}
.class-name {
    border-bottom: 1px solid black;
    border-radius: 38%;
    margin-left: -3px;
}
</style>
<html>
<head>
</head>
<body>

<table width="width:100%;height:101%;margin-right:10;z-index:3;background-color:lightgray"><tr>
    <td style="vertical-align:super;width:200;">
    <div style="vertical-align:super;height:850;border-right:3px solid silver;border-radius:10px;width:200">
        <br>
        <p>&nbsp;Class Includes</p>
        <hr style="background-color:black" width="10%">
        <p class="class-list" insert="methods" method="GET" id="api" ajax='classlist.php?class=api'>&nbsp;API</p>
        <p class="class-list" insert="methods" method="GET" id="css" ajax='classlist.php?class=css'>&nbsp;CSS</p>
        <p class="class-list" insert="methods" method="GET" id="dequeue" ajax='classlist.php?class=Dequeue'>&nbsp;Dequeue</p>
        <p class="class-list" insert="methods" method="GET" id="map" ajax='classlist.php?class=Map'>&nbsp;Map</p>
        <div style="border-left:1px dashed black;margin-left:10;text-align:center;width:120">
            <ul class="class-name" insert="methods" method="GET" id="mmap" ajax='classlist.php?class=mMap'>mMap</ul>
            <ul class="class-name" insert="methods" method="GET" id="navmap" ajax='classlist.php?class=NavigableMap'>NavigableMap</ul>
            <ul class="class-name" insert="methods" method="GET" id="smap" ajax='classlist.php?class=SortedMap'>SortedMap</ul>
        </div>
        <p class="class-list" insert="methods" method="GET" id="matrix" ajax='classlist.php?class=Matrix'>&nbsp;Matrix</p>
        <p class="class-list" insert="methods" method="GET" id="queue" ajax='classlist.php?class=Queue'>&nbsp;Queue</p>
        <p class="class-list" insert="methods" method="GET" id="set" ajax='classlist.php?class=Set'>&nbsp;Set</p>
        <div style="border-left:1px dashed black;margin-left:10;text-align:center;width:120">
            <ul class="class-name" insert="methods" method="GET" id="mset" ajax='classlist.php?class=mSet'>mSet</ul>
            <ul class="class-name" insert="methods" method="GET" id="navset" ajax='classlist.php?class=NavigableSet'>NavigableSet</ul>
            <ul class="class-name" insert="methods" method="GET" id="sset" ajax='classlist.php?class=SortedSet'>SortedSet</ul>
        </div>
        <p class="class-list" insert="methods" method="GET" id="stack" ajax='classlist.php?class=Stack'>&nbsp;Stack</p>
        <p class="class-list" insert="methods" method="GET" id="streams" ajax='classlist.php?class=Streams'>&nbsp;Streams</p>
        <div style="border-left:1px dashed black;margin-left:10;text-align:center;width:120">
            <ul class="class-name" insert="methods" method="GET" id="read" ajax='classlist.php?class=ReadStream'>Read</ul>
            <ul class="class-name" insert="methods" method="GET" id="write" ajax='classlist.php?class=WriteStream'>Write</ul>
            <ul class="class-name" insert="methods" method="GET" id="rwstream" ajax='classlist.php?class=RWStream'>Read/Write</ul>
        </div>
        <p class="class-list" insert="methods" method="GET" id="thread" ajax='classlist.php?class=Thread'>&nbsp;Threads</p>
        <p class="class-list" insert="methods" method="GET" id="xml" ajax='classlist.php?class=XML'>&nbsp;XML</p>
        <br>
        &nbsp;
    </div>
    </td>
    <td style="vertical-align:super;width:300">
    <section style="display:table;text-align:justify;width:500;">
        <block id="methods" style="display:table-row;text-align:justify">&nbsp;</block>
    </section>
    </td>
    <td style="vertical-align:super;width:200;">
    <div style="border-right:3px solid silver;height:850;vertical-align:super;border-radius:10px;width:200">
         <br>
        <p>&nbsp;Class Includes</p>
        <hr style="background-color:black" width="10%">
        <p class="class-list" insert="methods" method="GET" id="PASM" ajax='classlist.php?class=PASM'>&nbsp;PASM</p>
        <p class="class-list" insert="methods" method="GET" id="oauth2">&nbsp;OAuth2</p>
        <div style="border-left:1px dashed black;margin-left:10;text-align:center;width:120">
            <ul class="class-name" insert="methods" method="GET" id="oauth2owner" ajax='classlist.php?class=OAuth2Owner'>OAuth2Owner</ul>
            <ul class="class-name" insert="methods" method="GET" id="userclass" ajax='classlist.php?class=UserClass'>UserClass</ul>
            <ul class="class-name" insert="methods" method="GET" id="usercontrol" ajax='classlist.php?class=UserController'>UserController</ul>
            <ul class="class-name" insert="methods" method="GET" id="pageviews" ajax='classlist.php?class=CRUD'>CRUD</ul>
        </div>
        <p class="class-list" insert="methods" method="GET" id="ditto">&nbsp;Ditto</p>
        <?= str_repeat("&nbsp;", 5); ?> Unit Test Creator
        <p class="class-list" insert="methods" method="GET" id="wireframe">&nbsp;Wireframe</p>
        <div style="border-left:1px dashed black;margin-left:10;text-align:center;width:120">
            <ul class="class-name" insert="methods" method="GET" id="pagecon" ajax='classlist.php?class=PageControllers'>PageControllers</ul>
            <ul class="class-name" insert="methods" method="GET" id="pageerr" ajax='classlist.php?class=PageErrors'>PageErrors</ul>
            <ul class="class-name" insert="methods" method="GET" id="pagesmods" ajax='classlist.php?class=PageModels'>PageModels</ul>
            <ul class="class-name" insert="methods" method="GET" id="pageviews" ajax='classlist.php?class=PageViews'>PageViews</ul>
        </div>
        <p class="class-list" insert="methods" method="GET" id="router">&nbsp;CookieCheck</p>
            <?= str_repeat("&nbsp;", 5); ?> Javascript
        <p class="class-list" insert="methods" method="GET" id="routes" ajax='classlist.php?class=ChatBox'>&nbsp;ChatBox</p>
        <p class="class-list" insert="methods" method="GET" id="keys" ajax='classlist.php?class=Keywords'>&nbsp;Keywords</p>
        <p class="class-list" insert="methods" method="GET" id="trees" ajax='classlist.php?class=Trees'>&nbsp;Trees</p>
        <p class="class-list" insert="methods" method="GET" id="vector" ajax='classlist.php?class=Vectors'>&nbsp;Vector</p>
            <?= str_repeat("&nbsp;", 5); ?> Inherits all others
        <br>&nbsp;
    </div>
    </td>
</tr>
</table>
<script> 
makeCarousel(["example.txt", "composer.json"], "wise/src/icons/omniscroll.png", "wise/src/icons/omniscroll.png");
fillCarousel("example.txt, composer.json");
</script>