<?php

    $class = substr($_GET['class'],0,strpos($_GET['class'],'?'));
    echo $class;
    echo file_get_contents(strtolower("documentation/$class/$class.html"));

?>